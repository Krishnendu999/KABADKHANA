
public class Addition extends CalculatorBox {

	Addition(double firstnumb, double secondnumb) {
		super(firstnumb, secondnumb);
		super.numb1 = firstnumb;
		super.numb2 = secondnumb;
	}

	double Add() {
	
		super.Result = super.numb1 + super.numb2;
		return super.Result;
	}

}
