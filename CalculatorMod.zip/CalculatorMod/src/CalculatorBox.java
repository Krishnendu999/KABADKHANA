
public class CalculatorBox {

	double numb1;
	double numb2;
	double Result;

	CalculatorBox(double firstnumb, double secondnumb) {

	}

	double Add() {
		return Result;
	};

}
