import java.util.Scanner;

public class CallMain {

	static double Input1;
	static double Input2;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		Input1 = sc.nextDouble();
		System.out.println("Enter the second number");
		Input2 = sc.nextDouble();
		sc.close();
		CalculatorBox obj1 = new Addition(Input1, Input2);
		obj1.Add();
		System.out.println("Result" + obj1.Result);
		CalculatorBox obj2 = new Division(Input1, Input2);
		obj2.Divide();
		System.out.println("Result" + obj2.Result);
	}

}
