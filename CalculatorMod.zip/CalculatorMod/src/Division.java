
public class Division extends CalculatorBox {

	Division(double firstnumb, double secondnumb) {
		super(firstnumb, secondnumb);
		super.numb1 = firstnumb;
		super.numb2 = secondnumb;
	}

	double Divide() {
		
		try {
			super.Result = super.numb1 / super.numb2;
			return super.Result;
		}
		catch (Exception e) {
			System.out.println ("Cant Divide by Zero");
			super.Result = 0;
			return super.Result;
			
		}
		
	}

}
